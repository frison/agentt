# Yii2 autocomplete plugin

Adds autocomplete commands and subcommands for [yii](https://www.yiiframework.com/).

## Requirements

Autocomplete works from directory where your `yii` file is contained.
