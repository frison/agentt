# Watson

This plugin provides completion for [Watson](https://tailordev.github.io/Watson/).

To use it add `watson` to the plugins array in your zshrc file.

```zsh
plugins=(... watson)
```
