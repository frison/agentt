# DECLARATION: This plugin was created by hhatto. What I did is just making a portal from https://bitbucket.org/hhatto/zshcompfunc4supervisor.

alias sup='sudo supervisorctl'
alias supad='sudo supervisorctl add'
alias supa='sudo supervisorctl avail'
alias suprl='sudo supervisorctl reload'
alias suprm='sudo supervisorctl remove'
alias suprr='sudo supervisorctl reread'
alias suprs='sudo supervisorctl restart'
alias sups='sudo supervisorctl status'
alias supsr='sudo supervisorctl start'
alias supso='sudo supervisorctl stop'
alias supt='sudo supervisorctl tail'
alias supu='sudo supervisorctl update'
