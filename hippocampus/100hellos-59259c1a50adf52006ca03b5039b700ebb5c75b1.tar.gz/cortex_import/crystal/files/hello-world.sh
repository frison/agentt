#!/usr/bin/env sh

crystal hello-world.cr
