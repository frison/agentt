#!/usr/bin/env sh

chmod +x hello-world.sed
echo | ./hello-world.sed