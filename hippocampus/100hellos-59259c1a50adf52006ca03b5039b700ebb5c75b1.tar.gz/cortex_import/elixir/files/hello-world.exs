#!/usr/bin/env elixir

import IO, only: [puts: 1]

puts("Hello World!")

