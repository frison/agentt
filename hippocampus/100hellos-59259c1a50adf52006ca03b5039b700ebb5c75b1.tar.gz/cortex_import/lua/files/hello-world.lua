#!/usr/bin/env lua5.4

print("Hello World")
