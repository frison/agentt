#!/usr/bin/env sh

zig run hello-world.zig
