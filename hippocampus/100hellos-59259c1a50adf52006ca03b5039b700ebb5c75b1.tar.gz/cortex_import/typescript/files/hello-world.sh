#!/usr/bin/env sh

# Compile typescript for node.js
tsc hello-world.ts

# Run it
node hello-world.js