#!/usr/bin/env sh

unl < hello-world.unl
