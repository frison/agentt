#!/usr/bin/env php

<?php
echo "Hello World!";
?>