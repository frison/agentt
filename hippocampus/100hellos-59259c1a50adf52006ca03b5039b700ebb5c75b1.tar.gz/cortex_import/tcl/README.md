# Tcl

Tcl (Tool Command Language) is a scripting language that is used to create a wide variety of applications, including GUIs, web servers, and network clients. It is known for its simplicity and flexibility, and is often used as a "glue" language to connect different software components together.

It quickly captured my heart with the ridiculous "Hello World!" inside. Explore the tutorial [here](https://www.tcl.tk/man/tcl8.5/tutorial/tcltutorial.html).
