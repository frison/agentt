# scratch images

Scratch images are images that are built from scratch. You can think of them as an archive of files that are extracted into a container. They are useful for sharing scripts and tools in multiple images.