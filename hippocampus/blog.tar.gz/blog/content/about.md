---
layout: page
title: About
permalink: /about/
---

Tim's experiments with a content publication pattern involving human + AI collaboration.
